package Edad;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class LimiteEdad {
	@Test
    void testInvalidoMenorEdadLimite() {
        Edad age = new Edad();
        boolean supuesto = age.esMayorDeEdad(17);
        assertEquals(false, supuesto, "Error, la persona no es mayor de edad.");
    }
	
	@Test
    void testLimiteInferiorDentroRango() {
        Edad age = new Edad();
        boolean supuesto = age.esMayorDeEdad(18);
        assertEquals(true, supuesto, "Es mayor de edad");
    }
	
	@Test
    void testLimiteMaximorDentroRango() {
        Edad age = new Edad();
        boolean supuesto = age.esMayorDeEdad(100);
        assertEquals(true, supuesto, "Es mayor de edad");
    }
	
	@Test
    void testInvalidoMayorEdadLimite() {
        Edad age = new Edad();
        boolean supuesto = age.esMayorDeEdad(101);
        assertEquals(false, supuesto, "Error, la persona supera el rango de edad.");
    }
	
	
}
