package Edad;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class EquivalenciaEdad {
	private static Edad age = new Edad();
	
	@Test
    void testInvalidoMenorEdad() {
        boolean supuesto = age.esMayorDeEdad(13);
        assertEquals(false, supuesto, "Error, la persona no es mayor de edad.");
    }
	
	@Test
    void testInvalidoMayorEdadRango() {
        boolean supuesto = age.esMayorDeEdad(105);
        assertEquals(false, supuesto, "Error, la persona no entra en el rango.");
    }
}
