/**
 * 
 */
/**
 * 
 */
module PruebasIntegración {
	requires org.junit.jupiter.api;
}