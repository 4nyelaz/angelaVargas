package PruebasIntegracionAVR;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class PruebasIntegracionAVR {
	
	////////////////////////////////////////
	//EJERCICIO 1
    private final Ej1_BaseDeDatos baseDeDatosUsuarios = new Ej1_BaseDeDatos();
    private final Ej1_ServicioUsuarios servicioUsuarios = new Ej1_ServicioUsuarios(baseDeDatosUsuarios);
    
    @Test
    public void Ejercicio1() {
        String nombreUsuario = "Carlos";
        servicioUsuarios.registrarUsuario(nombreUsuario);
        assertTrue(servicioUsuarios.usuarioRegistrado(nombreUsuario));
    }
    
    ///////////////////////////////////////
    //EJERCICIO 2
    private final Ej2_ServicioEnvio servicioEnvio = new Ej2_ServicioEnvio();
    private final Ej2_ServicioPedido servicioPedidos = new Ej2_ServicioPedido(servicioEnvio);
    
     @Test
    public void Ejercicio2() {
        String idPedido = "Pedido123";
        servicioPedidos.crearYEnviarPedido(idPedido);
        assertTrue(servicioEnvio.enviarPedido(idPedido));
    }
     
    //////////////////////////////////////
    //EJERCICIO 3
    private final Ej3_BaseDeDatosProductos baseDeDatosProductos = new Ej3_BaseDeDatosProductos();
    private final Ej3_GestorProductos gestorProductos = new Ej3_GestorProductos(baseDeDatosProductos);
    
    @Test
    public void Ejercicio3() {
        String nombreProducto = "caja";
        gestorProductos.registrarProducto(nombreProducto);
        assertTrue(baseDeDatosProductos.verificarProducto(nombreProducto));
    }
    
    ///////////////////////////////////////
    // EJERCICIO 4
    private final Ej4_ServicioPagos servicioPagos = new Ej4_ServicioPagos();
    private final Ej4_ServicioOrdenes servicioOrdenes = new Ej4_ServicioOrdenes(servicioPagos);
    
    @Test
    public void pruebaProcesamientoPago() {
        double montoPago = 500.0;
        servicioOrdenes.procesarOrden(montoPago);
        assertEquals(500.0, servicioPagos.getSaldo());
    }
    
    ///////////////////////////////////////

    

   

    

    
}
